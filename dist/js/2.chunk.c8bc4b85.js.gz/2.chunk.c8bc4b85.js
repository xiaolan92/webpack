(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ "0tDW":
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__("JPst");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".qucklyGoods .table[data-v-3ea386f7]{margin-top:15px;min-height:700px}.qucklyGoods .header[data-v-3ea386f7]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}@media screen and (max-width: 1600px){.qucklyGoods .header[data-v-3ea386f7]{-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;height:90px}}.qucklyGoods .header .search-container[data-v-3ea386f7]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;width:100%;max-width:1300px}.qucklyGoods .header .search-container .search-btn[data-v-3ea386f7]{width:80px;height:38px;line-height:38px;text-align:center;color:white;cursor:pointer;background:#f7961c;border-radius:6px}.qucklyGoods .header .throughContainer[data-v-3ea386f7]{width:230px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}@media screen and (max-width: 1600px){.qucklyGoods .header .throughContainer[data-v-3ea386f7]{-ms-flex-item-align:end;align-self:flex-end}}.qucklyGoods .header .throughContainer .through[data-v-3ea386f7]{color:#f7961c;width:100px;height:35px;text-align:center;line-height:35px;border:1px solid #f7961c;border-radius:6px;cursor:pointer}.qucklyGoods .pagination[data-v-3ea386f7]{margin:20px 0}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "382s":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("4T6S");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("SZ7m").default
var update = add("045ec087", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "4T6S":
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__("JPst");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".qucklyGoods .table[data-v-71fd4c06]{margin-top:15px;min-height:700px}.qucklyGoods .header[data-v-71fd4c06]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}@media screen and (max-width: 1600px){.qucklyGoods .header[data-v-71fd4c06]{-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;height:90px}}.qucklyGoods .header .search-container[data-v-71fd4c06]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;width:100%;max-width:1300px}.qucklyGoods .header .search-container .search-btn[data-v-71fd4c06]{width:80px;height:38px;line-height:38px;text-align:center;color:white;cursor:pointer;background:#f7961c;border-radius:6px}.qucklyGoods .header .through-container[data-v-71fd4c06]{width:230px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}@media screen and (max-width: 1600px){.qucklyGoods .header .through-container[data-v-71fd4c06]{-ms-flex-item-align:end;align-self:flex-end}}.qucklyGoods .header .through[data-v-71fd4c06]{color:#f7961c;width:100px;height:35px;display:inline-block;text-align:center;line-height:35px;border:1px solid #f7961c;border-radius:6px;cursor:pointer}.qucklyGoods .header .margin[data-v-71fd4c06]{margin-left:20px}.qucklyGoods .pagination[data-v-71fd4c06]{margin:20px 0}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "66x0":
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__("JPst");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".lookcontainer[data-v-7a35d891]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column}.lookcontainer .header[data-v-7a35d891]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;width:320px;margin-bottom:20px}.lookcontainer .commen[data-v-7a35d891]{width:130px;height:37px;display:grid;place-items:center;border-radius:6px;cursor:pointer}.lookcontainer .active[data-v-7a35d891]{color:white;background:#f7961c}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "6NZq":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_first_vue_vue_type_style_index_0_id_71fd4c06_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("382s");
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_first_vue_vue_type_style_index_0_id_71fd4c06_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_first_vue_vue_type_style_index_0_id_71fd4c06_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_first_vue_vue_type_style_index_0_id_71fd4c06_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "6WKZ":
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__("JPst");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".dialog_style{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;margin:0 !important;position:absolute;top:50%;left:50%;-webkit-transform:translate(-50%, -50%);transform:translate(-50%, -50%);max-height:calc(100% - 30px);max-width:calc(100% - 30px)}.dialog_style .el-dialog__header{position:absolute;right:0;top:0}.dialog_style .el-dialog__body{-webkit-box-flex:1;-ms-flex:1;flex:1;overflow:auto}.dialog_style .el-dialog__body{padding:0}.dialog_style{height:700px;overflow:auto;background-color:#f6f6f6}.dialog_style img{vertical-align:middle;max-width:100%;max-height:100%}.dialog_style .border_base_info{margin-bottom:10px;padding:10px;background:#ffffff;border-radius:0px 0px 10px 10px}.dialog_style .row_price{margin-bottom:12px}.dialog_style .row_price .price01{color:#f95f2c;font-size:16px;font-weight:bold;position:relative;top:2px}.dialog_style .row_price .price02{color:#f95f2c;font-size:22px;font-weight:bold;position:relative;top:3px}.dialog_style .row_price .price03{margin-left:5px;padding:1px 5px;color:#f7961c;background:#faecd8;border-radius:3px;font-size:12px}.dialog_style .row_price .price04{margin-left:5px;padding:1px 5px;color:#f7961c;background:#faecd8;border-radius:3px;font-size:12px}.dialog_style .row_price .price05{float:right;margin-top:9px;padding:0 5px;color:#ffffff;background:#f95f2c;border:1px solid #f95f2c;border-radius:6px;font-size:12px}.dialog_style .row_title{margin-bottom:10px}.dialog_style .row_title .text{color:#222222;font-size:16px;font-weight:bold;line-height:20px}.dialog_style .row_title .tip{margin-left:5px;padding:1px 3px;background:#f7961c;border-radius:3px;color:#ffffff;font-size:12px;line-height:24px}.dialog_style .row_num{font-size:12px;color:#616262}.dialog_style .row_num span{margin-right:15px}.dialog_style .border_main{margin-bottom:20px;background-color:#fff;border-radius:10px;overflow:hidden}.dialog_style .border_main .bm_title{padding:15px 0;color:#222222;font-size:14px;text-align:center}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "89QR":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_second_vue_vue_type_style_index_0_id_3ea386f7_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("tRuQ");
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_second_vue_vue_type_style_index_0_id_3ea386f7_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_second_vue_vue_type_style_index_0_id_3ea386f7_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_second_vue_vue_type_style_index_0_id_3ea386f7_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "8Y6c":
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__("JPst");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".goods-container .size[data-v-12335ba3]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;margin-bottom:10px}.goods-container .size .title-container[data-v-12335ba3]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;width:500px}.goods-container .size .title-container .delete_btn[data-v-12335ba3]{width:100px;height:35px;line-height:35px;text-align:center;border:1px solid rgba(0, 0, 0, .2);border-radius:5px;cursor:pointer}.goods-container .size .title-container .addRowItem[data-v-12335ba3]{width:130px;height:37px;line-height:37px;text-align:center;background:#409EFF;border-radius:5px;color:white;cursor:pointer}.goods-container .size .innerInput[data-v-12335ba3]{margin-top:5px}.goods-container .size .innerAdd[data-v-12335ba3]{margin-left:10px}.goods-container .price[data-v-12335ba3]{margin-left:30px}.goods-container .width[data-v-12335ba3]{width:300px}.goods-container .select[data-v-12335ba3]{margin-left:15px}.goods-container .input-container[data-v-12335ba3]{height:90px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "AZ6I":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_details_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("s/Li");
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_details_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_details_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_details_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "Gzxi":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return client; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return setImgName; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("o0o1");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("yXPU");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ali_oss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("mxV5");
/* harmony import */ var ali_oss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ali_oss__WEBPACK_IMPORTED_MODULE_2__);



/* eslint-disable consistent-return */

/* eslint-disable one-var */
 // 阿里云图片oss配置

var client = function client() {
  return new ali_oss__WEBPACK_IMPORTED_MODULE_2___default.a({
    region: "oss-cn-beijing",
    accessKeyId: "LTAI4G4GvvKZwgrgCVguwAHz",
    accessKeySecret: "mDZSsy2WAXNjZfCVJkAs2T0RtJOzNF",
    bucket: "suixinsuiyi"
  });
}; // 阿里云上传图片命名

var setImgName = /*#__PURE__*/function () {
  var _ref = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(clientOss, file, folder) {
    var suffixArr, suffix, date, day, fileName, res;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            // 上传文件类型
            suffixArr = file.file.name.split("."), suffix = suffixArr[suffixArr.length - 1], date = new Date(), day = String(date.getFullYear()) + (date.getMonth() + 1) + date.getDate(), fileName = String(date.getFullYear()) + (date.getMonth() + 1) + date.getDate() + date.getMilliseconds();
            _context.prev = 1;
            _context.next = 4;
            return clientOss.put("backstage/".concat(day, "/").concat(folder, "/").concat(fileName, ".").concat(suffix), file.file, {
              headers: {
                "Content-Disposition": "inline",
                "Content-Type": suffix
              }
            });

          case 4:
            res = _context.sent;
            console.log(res);
            return _context.abrupt("return", res.url);

          case 9:
            _context.prev = 9;
            _context.t0 = _context["catch"](1);
            console.log(_context.t0);

          case 12:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[1, 9]]);
  }));

  return function setImgName(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();

/***/ }),

/***/ "JXHu":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./src/components/details.vue?vue&type=template&id=8d64e93c&
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "goods-container" },
    [
      _c(
        "el-dialog",
        {
          attrs: {
            visible: _vm.detailsVisible,
            width: "393px",
            center: "",
            "before-close": _vm.close,
            "custom-class": "dialog_style"
          },
          on: {
            "update:visible": function($event) {
              _vm.detailsVisible = $event
            }
          }
        },
        [
          _c(
            "el-carousel",
            {
              attrs: {
                height: "375px",
                autoplay: false,
                trigger: "click",
                "indicator-position": _vm.indicatorPosition
              },
              on: { change: _vm.carouselChange }
            },
            _vm._l(_vm.rowData.first_img, function(item, index) {
              return _c("el-carousel-item", { key: index }, [
                item.suffixVal == 1
                  ? _c(
                      "video",
                      {
                        attrs: {
                          id: "video",
                          src: item.url,
                          height: "375",
                          width: "375",
                          preloader: "auto",
                          controls: ""
                        }
                      },
                      [_c("p", [_vm._v("你的浏览器不支持video标签")])]
                    )
                  : _c("img", {
                      attrs: { src: item.url, width: "375px", height: "375px" }
                    })
              ])
            }),
            1
          ),
          _vm._v(" "),
          _c("div", { staticClass: "border_base_info" }, [
            _c("div", { staticClass: "row_price" }, [
              _c("span", { staticClass: "price01" }, [_vm._v("￥")]),
              _c("span", { staticClass: "price02" }, [
                _vm._v(_vm._s(_vm.rowData.market_price))
              ]),
              _vm._v(" "),
              _c("span", { staticClass: "price03" }, [
                _vm._v(_vm._s(_vm.rowData.integral_price) + "积分")
              ]),
              _vm._v(" "),
              _c("span", { staticClass: "price04" }, [
                _vm._v(_vm._s(_vm.rowData.coupons_price) + "券")
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row_title" }, [
              _c("span", { staticClass: "text" }, [
                _vm._v(_vm._s(_vm.rowData.goods_name))
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "row_num" }, [
              _c("span", [_vm._v("库存：" + _vm._s(_vm.rowData.inventory))]),
              _vm._v(" "),
              _c("span", [_vm._v("已售：" + _vm._s(_vm.rowData.sales))])
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "border_main" }, [
            _c("div", { staticClass: "bm_title" }, [
              _vm._v("\n        产品介绍\n      ")
            ]),
            _vm._v(" "),
            _c(
              "div",
              _vm._l(_vm.rowData.details, function(item, index) {
                return _c("div", { key: index }, [
                  _c("img", { attrs: { src: item } })
                ])
              }),
              0
            )
          ])
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true


// CONCATENATED MODULE: ./src/components/details.vue?vue&type=template&id=8d64e93c&

// CONCATENATED MODULE: ./node_modules/happypack/loader.js?id=babel!./node_modules/vue-loader/lib??vue-loader-options!./src/components/details.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ var detailsvue_type_script_lang_js_ = ({
  data: function data() {
    return {
      // 是否显示幻灯片的 切换按钮 默认不显示
      indicatorPosition: "none"
    };
  },
  props: {
    detailsVisible: {
      type: Boolean,
      defautl: false
    },
    rowData: {
      type: Object,
      default: function _default() {
        return {};
      }
    }
  },
  methods: {
    close: function close() {
      // eslint-disable-next-line camelcase
      this.rowData.first_img = [];
      this.$emit("update:detailsVisible", false);

      if (document.getElementById("video")) {
        document.getElementById("video").pause();
      }
    },
    // 幻灯片切换时，进行相应判断
    carouselChange: function carouselChange(index) {
      if (this.rowData.first_img[index].suffixVal === 1) {
        this.indicatorPosition = "none";
        document.getElementById("video").pause();
      } else {
        this.indicatorPosition = "";
      }
    }
  },
  components: {},
  watch: {
    // 监听父组件传递过来的值 然后进行相应判断 是否显示幻灯片按钮
    rowData: function rowData(obj) {
      if (obj.first_img[0].suffixVal === 1) {
        this.indicatorPosition = "none";
      } else {
        this.indicatorPosition = "";
      }
    }
  }
});
// CONCATENATED MODULE: ./src/components/details.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_detailsvue_type_script_lang_js_ = (detailsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/components/details.vue?vue&type=style&index=0&lang=scss&
var detailsvue_type_style_index_0_lang_scss_ = __webpack_require__("AZ6I");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("KHd+");

// CONCATENATED MODULE: ./src/components/details.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  components_detailsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/details.vue"
/* harmony default export */ var details = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "c8BC":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_generalGoods_vue_vue_type_style_index_0_id_7a35d891_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("gfTd");
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_generalGoods_vue_vue_type_style_index_0_id_7a35d891_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_generalGoods_vue_vue_type_style_index_0_id_7a35d891_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_generalGoods_vue_vue_type_style_index_0_id_7a35d891_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "gKUm":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./src/views/goodsManage/generalGoods/generalGoods.vue?vue&type=template&id=7a35d891&scoped=true&
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "lookcontainer" }, [
    _c(
      "div",
      { staticClass: "header" },
      _vm._l(_vm.goodsType, function(item, index) {
        return _c(
          "div",
          {
            key: index,
            class: ["commen", { active: _vm.currentComponent === item.path }],
            on: {
              click: function($event) {
                _vm.currentComponent = item.path
              }
            }
          },
          [_vm._v("\n      " + _vm._s(item.title) + "\n    ")]
        )
      }),
      0
    ),
    _vm._v(" "),
    _c("div", [_c(_vm.currentComponent, { tag: "component" })], 1)
  ])
}
var staticRenderFns = []
render._withStripped = true


// CONCATENATED MODULE: ./src/views/goodsManage/generalGoods/generalGoods.vue?vue&type=template&id=7a35d891&scoped=true&

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./src/views/goodsManage/generalGoods/first.vue?vue&type=template&id=71fd4c06&scoped=true&
var firstvue_type_template_id_71fd4c06_scoped_true_render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "qucklyGoods" },
    [
      _c("Goods", {
        attrs: {
          "goods-detail": _vm.goodsDetail,
          "dialog-visible": _vm.dialogVisible
        },
        on: { getData: _vm.getGoods, setDialogVisible: _vm.setDialogVisible }
      }),
      _vm._v(" "),
      _c("Detail", {
        attrs: {
          "details-visible": _vm.detailsVisible,
          "row-data": _vm.rowData
        },
        on: {
          "update:detailsVisible": function($event) {
            _vm.detailsVisible = $event
          },
          "update:details-visible": function($event) {
            _vm.detailsVisible = $event
          }
        }
      }),
      _vm._v(" "),
      _c("header", { staticClass: "header" }, [
        _c(
          "div",
          { staticClass: "search-container" },
          [
            _c("el-date-picker", {
              staticClass: "size",
              attrs: {
                type: "date",
                placeholder: "开始时间",
                "picker-options": _vm.pickerOptions
              },
              model: {
                value: _vm.startTime,
                callback: function($$v) {
                  _vm.startTime = $$v
                },
                expression: "startTime"
              }
            }),
            _vm._v(" "),
            _c("el-date-picker", {
              staticClass: "size",
              attrs: {
                type: "date",
                placeholder: "结束时间",
                "picker-options": _vm.pickerOptions
              },
              model: {
                value: _vm.endTime,
                callback: function($$v) {
                  _vm.endTime = $$v
                },
                expression: "endTime"
              }
            }),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "bus_name" },
              [
                _c("el-input", {
                  staticClass: "size",
                  attrs: { placeholder: "请输入商家名称" }
                })
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "shop_name" },
              [
                _c("el-input", {
                  staticClass: "size",
                  attrs: { placeholder: "请输入商品名称" }
                })
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "el-select",
              {
                staticStyle: { width: "110px" },
                attrs: { placeholder: "商品状态", clearable: "" },
                model: {
                  value: _vm.value,
                  callback: function($$v) {
                    _vm.value = $$v
                  },
                  expression: "value"
                }
              },
              _vm._l(_vm.options, function(item) {
                return _c("el-option", {
                  key: item.value,
                  attrs: { label: item.label, value: item.value }
                })
              }),
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "search-btn", on: { click: _vm.serach } },
              [_vm._v("\n        确定\n      ")]
            )
          ],
          1
        ),
        _vm._v(" "),
        _c("div", { staticClass: "through-container" }, [
          _c(
            "div",
            {
              staticClass: "through",
              on: {
                click: function($event) {
                  return _vm.pass(0)
                }
              }
            },
            [_vm._v("\n        批量驳回\n      ")]
          ),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "through margin",
              on: {
                click: function($event) {
                  return _vm.pass(1)
                }
              }
            },
            [_vm._v("\n        批量通过\n      ")]
          )
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "table" },
        [
          _c(
            "el-table",
            {
              ref: "table",
              staticStyle: {},
              attrs: {
                data: _vm.tableData.list,
                border: "",
                "header-cell-style": { "text-align": "center", color: "black" },
                "cell-style": { "text-align": "center", padding: "5px 0" }
              },
              on: { "selection-change": _vm.handleSelect }
            },
            [
              _c("el-table-column", {
                attrs: { type: "selection", width: "60px" }
              }),
              _vm._v(" "),
              _c("el-table-column", { attrs: { prop: "id", label: "序号" } }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: {
                  prop: "goods_name",
                  label: "商品名称",
                  "show-overflow-tooltip": true
                }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "封面" },
                scopedSlots: _vm._u([
                  {
                    key: "default",
                    fn: function(scope) {
                      return [
                        _c("img", {
                          staticStyle: { width: "40px", height: "40px" },
                          attrs: { src: scope.row.cover_img }
                        })
                      ]
                    }
                  }
                ])
              }),
              _vm._v(" "),
              _c("el-table-column", { attrs: { prop: "sort", label: "排序" } }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "库存", prop: "inventory" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "支付类型", prop: "pay_type" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "原价", prop: "original_price" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "市场价", prop: "market_price" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "积分价格", prop: "is_integral" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "优惠券价格", prop: "coupons_price" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "状态", prop: "desStatus" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: {
                  prop: "created_at",
                  label: "创建时间",
                  "show-overflow-tooltip": true
                }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: {
                  prop: "updated_at",
                  label: "更新时间",
                  "show-overflow-tooltip": true
                }
              }),
              _vm._v(" "),
              _c(
                "el-table-column",
                {
                  attrs: { width: "300px" },
                  scopedSlots: _vm._u([
                    {
                      key: "default",
                      fn: function(scope) {
                        return [
                          _c(
                            "el-button",
                            {
                              attrs: { size: "mini" },
                              on: {
                                click: function($event) {
                                  return _vm.modify(scope.row.id)
                                }
                              }
                            },
                            [_vm._v("\n            修改\n          ")]
                          ),
                          _vm._v(" "),
                          _c(
                            "el-button",
                            {
                              attrs: { type: "primary", size: "mini" },
                              on: {
                                click: function($event) {
                                  return _vm.rowSee(scope.row)
                                }
                              }
                            },
                            [_vm._v("\n            预览\n          ")]
                          ),
                          _vm._v(" "),
                          _c("el-switch", {
                            staticStyle: { "margin-left": "30px" },
                            attrs: {
                              "active-text": "通过",
                              "inactive-text": "驳回"
                            },
                            on: {
                              change: function($event) {
                                return _vm.change(scope.row)
                              }
                            },
                            model: {
                              value: scope.row.status,
                              callback: function($$v) {
                                _vm.$set(scope.row, "status", $$v)
                              },
                              expression: "scope.row.status"
                            }
                          })
                        ]
                      }
                    }
                  ])
                },
                [
                  _c(
                    "template",
                    { attrs: { "slot-scope": _vm.scope }, slot: "header" },
                    [_vm._v("\n          操作\n        ")]
                  )
                ],
                2
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "pagination" },
        [
          _c("el-pagination", {
            attrs: {
              layout: "prev,pager,next",
              background: "",
              "page-size": _vm.limit,
              total: _vm.tableData.total
            },
            on: {
              "current-change": _vm.changePage,
              "prev-click": _vm.prev,
              "next-click": _vm.next
            }
          })
        ],
        1
      )
    ],
    1
  )
}
var firstvue_type_template_id_71fd4c06_scoped_true_staticRenderFns = []
firstvue_type_template_id_71fd4c06_scoped_true_render._withStripped = true


// CONCATENATED MODULE: ./src/views/goodsManage/generalGoods/first.vue?vue&type=template&id=71fd4c06&scoped=true&

// EXTERNAL MODULE: ./node_modules/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__("o0o1");
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("yXPU");
var asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(asyncToGenerator);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./src/views/goodsManage/generalGoods/goods.vue?vue&type=template&id=12335ba3&scoped=true&
var goodsvue_type_template_id_12335ba3_scoped_true_render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.goodsDetail.details
    ? _c(
        "div",
        { staticClass: "goods-container" },
        [
          _c(
            "el-dialog",
            {
              attrs: {
                visible: _vm.dialogVisible,
                width: "900px",
                center: "",
                "before-close": _vm.close
              },
              on: {
                "update:visible": function($event) {
                  _vm.dialogVisible = $event
                }
              }
            },
            [
              _c(
                "el-form",
                { attrs: { "label-width": "130px" } },
                [
                  _c(
                    "el-form-item",
                    { attrs: { label: "普通商品分类" } },
                    [
                      _c(
                        "el-select",
                        {
                          attrs: { clearable: "", placeholder: "请选择" },
                          model: {
                            value: _vm.value,
                            callback: function($$v) {
                              _vm.value = $$v
                            },
                            expression: "value"
                          }
                        },
                        _vm._l(_vm.goodsSort, function(item, index) {
                          return _c("el-option", {
                            key: index,
                            attrs: { label: item.name, value: item.id }
                          })
                        }),
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("el-form-item", { attrs: { label: "商品名称" } }, [
                    _c(
                      "div",
                      { staticStyle: { width: "400px" } },
                      [
                        _c("el-input", {
                          model: {
                            value: _vm.goodsDetail.goods_name,
                            callback: function($$v) {
                              _vm.$set(_vm.goodsDetail, "goods_name", $$v)
                            },
                            expression: "goodsDetail.goods_name"
                          }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c(
                    "el-form-item",
                    { attrs: { label: "封面" } },
                    [
                      _c(
                        "el-upload",
                        {
                          ref: "faceImg",
                          staticStyle: { display: "inline" },
                          attrs: {
                            action: "",
                            "http-request": _vm.UploadFaceImg,
                            "list-type": "picture-card",
                            multiple: ""
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "el-icon-plus",
                            attrs: { slot: "default" },
                            slot: "default"
                          })
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "transition",
                        { attrs: { name: "el-fade-in-linear" } },
                        [
                          _c(
                            "span",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: _vm.isfaceImgShow,
                                  expression: "isfaceImgShow"
                                }
                              ]
                            },
                            [
                              _c("img", {
                                staticStyle: {
                                  height: "150px",
                                  width: "150px"
                                },
                                attrs: { src: _vm.goodsDetail.cover_img }
                              })
                            ]
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "el-form-item",
                    { attrs: { label: "上传视频/图片" } },
                    [
                      _c(
                        "el-upload",
                        {
                          ref: "uploadFirst",
                          staticStyle: { display: "inline" },
                          attrs: {
                            action: "",
                            "http-request": _vm.Upload,
                            "list-type": "picture-card"
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "el-icon-plus",
                            attrs: { slot: "default" },
                            slot: "default"
                          })
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "transition",
                        { attrs: { name: "el-fade-in-linear" } },
                        [
                          _c(
                            "span",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: _vm.isFirstImgShow,
                                  expression: "isFirstImgShow"
                                }
                              ]
                            },
                            _vm._l(
                              _vm.goodsDetail.first_img.split(","),
                              function(item, index) {
                                return _c("img", {
                                  key: index,
                                  staticStyle: {
                                    height: "150px",
                                    width: "150px"
                                  },
                                  attrs: { src: item }
                                })
                              }
                            ),
                            0
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "el-form-item",
                    { attrs: { label: "规格" } },
                    [
                      _vm._l(_vm.goodsDetail.specifications, function(
                        item,
                        index
                      ) {
                        return _c("div", { key: index, staticClass: "size" }, [
                          _c(
                            "div",
                            { staticClass: "title-container" },
                            [
                              _c("el-input", {
                                staticStyle: { width: "250px" },
                                attrs: { placeholder: "请添加规格分类" },
                                model: {
                                  value: item.title,
                                  callback: function($$v) {
                                    _vm.$set(item, "title", $$v)
                                  },
                                  expression: "item.title"
                                }
                              }),
                              _vm._v(" "),
                              _c(
                                "span",
                                {
                                  staticClass: "addRowItem",
                                  on: {
                                    click: function($event) {
                                      return _vm.addRowItem(index)
                                    }
                                  }
                                },
                                [_vm._v("添加规格项")]
                              ),
                              _vm._v(" "),
                              _c(
                                "span",
                                {
                                  staticClass: "delete_btn",
                                  on: {
                                    click: function($event) {
                                      return _vm.deleteSizeItem(index)
                                    }
                                  }
                                },
                                [_vm._v("\n              删除\n            ")]
                              )
                            ],
                            1
                          ),
                          _vm._v(" "),
                          item.child.length > 0
                            ? _c(
                                "div",
                                { staticClass: "innerInput" },
                                [
                                  _vm._l(item.child, function(i, k) {
                                    return _c(
                                      "div",
                                      { key: k },
                                      [
                                        _c("el-input", {
                                          staticStyle: { width: "200px" },
                                          attrs: {
                                            placeholder:
                                              "请输入规格项,如颜色,尺寸"
                                          },
                                          model: {
                                            value: i.innerValue,
                                            callback: function($$v) {
                                              _vm.$set(i, "innerValue", $$v)
                                            },
                                            expression: "i.innerValue"
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c("el-input", {
                                          staticStyle: { width: "200px" },
                                          attrs: { placeholder: "请输入价格" },
                                          model: {
                                            value: i.cPrice,
                                            callback: function($$v) {
                                              _vm.$set(i, "cPrice", $$v)
                                            },
                                            expression: "i.cPrice"
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c(
                                          "el-upload",
                                          {
                                            staticStyle: { display: "inline" },
                                            attrs: {
                                              "show-file-list": false,
                                              action: "",
                                              "http-request":
                                                _vm.SizeItemUpload,
                                              "on-change": function(
                                                file,
                                                fileList
                                              ) {
                                                _vm.hanldChange(
                                                  file,
                                                  fileList,
                                                  index,
                                                  k
                                                )
                                              }
                                            }
                                          },
                                          [
                                            _c(
                                              "el-button",
                                              { attrs: { type: "primary" } },
                                              [
                                                _vm._v(
                                                  "\n                  上传图片\n                "
                                                )
                                              ]
                                            )
                                          ],
                                          1
                                        )
                                      ],
                                      1
                                    )
                                  }),
                                  _vm._v(" "),
                                  _c("el-button", {
                                    attrs: {
                                      icon: "el-icon-delete",
                                      size: "small"
                                    },
                                    on: {
                                      click: function($event) {
                                        return _vm.deleteInnerItem(index)
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("el-button", {
                                    staticClass: "innerAdd",
                                    attrs: {
                                      type: "primary",
                                      icon: "el-icon-plus",
                                      size: "small"
                                    },
                                    on: {
                                      click: function($event) {
                                        return _vm.addInnerItem(index)
                                      }
                                    }
                                  })
                                ],
                                2
                              )
                            : _vm._e()
                        ])
                      }),
                      _vm._v(" "),
                      _c(
                        "el-button",
                        {
                          attrs: { type: "primary" },
                          on: { click: _vm.addSizeItem }
                        },
                        [_vm._v("\n          添加规格\n        ")]
                      )
                    ],
                    2
                  ),
                  _vm._v(" "),
                  _c("el-form-item", { attrs: { label: "库存" } }, [
                    _c(
                      "div",
                      { staticStyle: { width: "300px" } },
                      [
                        _c("el-input", {
                          model: {
                            value: _vm.goodsDetail.inventory,
                            callback: function($$v) {
                              _vm.$set(_vm.goodsDetail, "inventory", $$v)
                            },
                            expression: "goodsDetail.inventory"
                          }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("el-form-item", { attrs: { label: "排序" } }, [
                    _c(
                      "div",
                      { staticStyle: { width: "300px" } },
                      [
                        _c("el-input", {
                          model: {
                            value: _vm.goodsDetail.sort,
                            callback: function($$v) {
                              _vm.$set(_vm.goodsDetail, "sort", $$v)
                            },
                            expression: "goodsDetail.sort"
                          }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c(
                    "el-form-item",
                    { attrs: { label: "商品简介" } },
                    [
                      _c("el-input", {
                        attrs: { type: "textarea", rows: 5 },
                        model: {
                          value: _vm.goodsDetail.describe,
                          callback: function($$v) {
                            _vm.$set(_vm.goodsDetail, "describe", $$v)
                          },
                          expression: "goodsDetail.describe"
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "el-form-item",
                    { attrs: { label: "商品详情" } },
                    [
                      _c(
                        "el-upload",
                        {
                          ref: "uploadTwo",
                          staticStyle: { display: "inline" },
                          attrs: {
                            action: "",
                            "http-request": _vm.detailImgsUpload,
                            "list-type": "picture-card"
                          }
                        },
                        [
                          _c("i", {
                            staticClass: "el-icon-plus",
                            attrs: { slot: "default" },
                            slot: "default"
                          })
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "transition",
                        { attrs: { name: "el-fade-in-linear" } },
                        [
                          _c(
                            "span",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: _vm.desImgShow,
                                  expression: "desImgShow"
                                }
                              ]
                            },
                            _vm._l(_vm.goodsDetail.details.split(","), function(
                              item,
                              index
                            ) {
                              return _c("img", {
                                key: index,
                                staticStyle: {
                                  height: "150px",
                                  width: "150px"
                                },
                                attrs: { src: item }
                              })
                            }),
                            0
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "el-form-item",
                    { attrs: { label: "原价" } },
                    [
                      _c("el-input", {
                        staticClass: "width",
                        model: {
                          value: _vm.goodsDetail.original_price,
                          callback: function($$v) {
                            _vm.$set(_vm.goodsDetail, "original_price", $$v)
                          },
                          expression: "goodsDetail.original_price"
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "el-form-item",
                    { attrs: { label: "现价" } },
                    [
                      _c("el-input", {
                        staticClass: "width",
                        model: {
                          value: _vm.goodsDetail.market_price,
                          callback: function($$v) {
                            _vm.$set(_vm.goodsDetail, "market_price", $$v)
                          },
                          expression: "goodsDetail.market_price"
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "el-form-item",
                    { attrs: { label: "混合支付" } },
                    [
                      _c("el-switch", {
                        model: {
                          value: _vm.isPay,
                          callback: function($$v) {
                            _vm.isPay = $$v
                          },
                          expression: "isPay"
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "el-select",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.isPay,
                              expression: "isPay"
                            }
                          ],
                          staticClass: "select",
                          model: {
                            value: _vm.currentPay,
                            callback: function($$v) {
                              _vm.currentPay = $$v
                            },
                            expression: "currentPay"
                          }
                        },
                        _vm._l(_vm.payWay, function(item, index) {
                          return _c("el-option", {
                            key: index,
                            attrs: { label: item.title, value: item.id }
                          })
                        }),
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.isPay
                    ? _c("el-form-item", [
                        _c(
                          "div",
                          { staticClass: "input-container" },
                          [
                            _c("el-input", {
                              staticClass: "width",
                              attrs: { placeholder: "请输入积分数量" },
                              model: {
                                value: _vm.goodsDetail.integral_price,
                                callback: function($$v) {
                                  _vm.$set(
                                    _vm.goodsDetail,
                                    "integral_price",
                                    $$v
                                  )
                                },
                                expression: "goodsDetail.integral_price"
                              }
                            }),
                            _vm._v(" "),
                            _c("el-input", {
                              staticClass: "width",
                              attrs: { placeholder: "请输入优惠卷价格" },
                              model: {
                                value: _vm.goodsDetail.coupons_price,
                                callback: function($$v) {
                                  _vm.$set(
                                    _vm.goodsDetail,
                                    "coupons_price",
                                    $$v
                                  )
                                },
                                expression: "goodsDetail.coupons_price"
                              }
                            })
                          ],
                          1
                        )
                      ])
                    : _vm._e()
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "span",
                {
                  staticClass: "dialog-footer",
                  attrs: { slot: "footer" },
                  slot: "footer"
                },
                [
                  _c(
                    "el-button",
                    {
                      on: {
                        click: function($event) {
                          _vm.dialogVisible = false
                        }
                      }
                    },
                    [_vm._v("取 消")]
                  ),
                  _vm._v(" "),
                  _c(
                    "el-button",
                    { attrs: { type: "primary" }, on: { click: _vm.confirm } },
                    [_vm._v("确 定")]
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    : _vm._e()
}
var goodsvue_type_template_id_12335ba3_scoped_true_staticRenderFns = []
goodsvue_type_template_id_12335ba3_scoped_true_render._withStripped = true


// CONCATENATED MODULE: ./src/views/goodsManage/generalGoods/goods.vue?vue&type=template&id=12335ba3&scoped=true&

// EXTERNAL MODULE: ./src/config/oss.js
var oss = __webpack_require__("Gzxi");

// CONCATENATED MODULE: ./node_modules/happypack/loader.js?id=babel!./node_modules/vue-loader/lib??vue-loader-options!./src/views/goodsManage/generalGoods/goods.vue?vue&type=script&lang=js&


//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var goodsvue_type_script_lang_js_ = ({
  data: function data() {
    return {
      value: "",
      // 是否开启混合支付
      isPay: false,
      FirstImgShow: [],
      isfaceImgShow: true,
      isFirstImgShow: true,
      desImgShow: true,
      coverImg: "",
      desImgs: [],
      // 普通商品分类
      goodsSort: [],
      // 上传视频/图片
      sortImgUrl: "",
      // 规格列表项图片
      sizeItemImgUrl: "",
      // 详情图
      desImg: "",
      currentPay: " ",
      payWay: [{
        title: "余额+积分+优惠券",
        id: 1
      }, {
        title: "积分",
        id: 0
      }]
    };
  },
  props: {
    dialogVisible: {
      type: Boolean,
      defautl: false
    },
    goodsDetail: {
      type: Object,
      default: function _default() {
        return {};
      }
    }
  },
  created: function created() {
    this.getGoodsSort();
  },
  methods: {
    // 上传封面图
    UploadFaceImg: function UploadFaceImg(file) {
      var _this = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee() {
        var url;
        return regenerator_default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return Object(oss["b" /* setImgName */])(Object(oss["a" /* client */])(), file, "faceImg");

              case 2:
                url = _context.sent;
                // eslint-disable-next-line camelcase
                _this.coverImg = url;
                _this.isfaceImgShow = false;

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    // 分类图片上传
    Upload: function Upload(file) {
      var _this2 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee2() {
        var url;
        return regenerator_default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return Object(oss["b" /* setImgName */])(Object(oss["a" /* client */])(), file, "sort");

              case 2:
                url = _context2.sent;

                _this2.FirstImgShow.push(url);

                _this2.isFirstImgShow = false;

              case 5:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    // 增加规格项列表数量
    addInnerItem: function addInnerItem(index) {
      if (this.goodsDetail.specifications[index].child.length < 10) {
        this.goodsDetail.specifications[index].child.push({
          innerValue: "",
          imageUrl: "",
          cPrice: 0
        });
      }
    },
    // 删除规格项列表数量
    deleteInnerItem: function deleteInnerItem(index) {
      this.goodsDetail.specifications[index].child.pop();
    },
    addRowItem: function addRowItem(index) {
      this.goodsDetail.specifications[index].child.push({
        innerValue: "",
        imageUrl: "",
        cPrice: 0
      });
    },
    // 增加规格项
    addSizeItem: function addSizeItem() {
      if (!this.goodsDetail.specifications) {
        this.goodsDetail.specifications = [];
      }

      this.goodsDetail.specifications.push({
        title: "",
        child: []
      });
    },
    // 删除规格项
    deleteSizeItem: function deleteSizeItem(index) {
      this.goodsDetail.specifications.splice(index, 1);
    },
    // 上传规格项目图
    SizeItemUpload: function SizeItemUpload(file) {
      var _this3 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee3() {
        var url;
        return regenerator_default.a.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return Object(oss["b" /* setImgName */])(Object(oss["a" /* client */])(), file, "sizeImg");

              case 2:
                url = _context3.sent;
                _this3.sizeItemImgUrl = url;

              case 4:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    hanldChange: function hanldChange(file, fileList, index, k) {
      this.goodsDetail.specifications[index].child[k].imageUrl = this.sizeItemImgUrl;
    },
    // 详情图片上传
    detailImgsUpload: function detailImgsUpload(file) {
      var _this4 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee4() {
        var url;
        return regenerator_default.a.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return Object(oss["b" /* setImgName */])(Object(oss["a" /* client */])(), file, "detailImg");

              case 2:
                url = _context4.sent;

                _this4.desImgs.push(url);

                _this4.desImgShow = false;

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    // 获取普通商品分类
    getGoodsSort: function getGoodsSort() {
      var _this5 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee5() {
        var res;
        return regenerator_default.a.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.prev = 0;
                _context5.next = 3;
                return _this5.axios.get("/goods/config/nav/list", {
                  params: {
                    // 普通商品
                    type: 1,
                    pages: 1,
                    limit: 50
                  }
                });

              case 3:
                res = _context5.sent;
                _this5.goodsSort = res.data.list;
                _context5.next = 10;
                break;

              case 7:
                _context5.prev = 7;
                _context5.t0 = _context5["catch"](0);
                console.log(_context5.t0);

              case 10:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, null, [[0, 7]]);
      }))();
    },
    // 更新普通商品
    confirm: function confirm() {
      var _this6 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee6() {
        var i, res;
        return regenerator_default.a.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                i = 0;

              case 1:
                if (!(i < _this6.goodsDetail.specifications.length)) {
                  _context6.next = 8;
                  break;
                }

                if (_this6.goodsDetail.specifications[i].title) {
                  _context6.next = 5;
                  break;
                }

                _this6.$message.warning({
                  message: "请添加规格分类"
                });

                return _context6.abrupt("return");

              case 5:
                i++;
                _context6.next = 1;
                break;

              case 8:
                _context6.prev = 8;
                _context6.next = 11;
                return _this6.axios.post("/goods/update", {
                  id: _this6.goodsDetail.id,
                  pid: _this6.value || _this6.goodsDetail.pid,
                  lastPid: 0,
                  "pay_type": _this6.currentPay ? 0 : _this6.currentPay,
                  "cover_img": _this6.coverImg || _this6.goodsDetail.cover_img,
                  firstImg: _this6.FirstImgShow.join(",") || _this6.goodsDetail.first_img,
                  specifications: _this6.goodsDetail.specifications || [],
                  inventory: _this6.goodsDetail.inventory,
                  // 普通商品
                  type: 2,
                  describe: _this6.goodsDetail.describe,
                  goodsName: _this6.goodsDetail.goods_name,
                  sort: _this6.goodsDetail.sort,
                  details: _this6.desImgs.join(",") || _this6.goodsDetail.details,
                  oPrice: _this6.goodsDetail.original_price,
                  mPrice: _this6.goodsDetail.market_price,
                  iPrice: _this6.goodsDetail.integral_price,
                  cPrice: _this6.goodsDetail.coupons_price
                });

              case 11:
                res = _context6.sent;

                _this6.close();

                _this6.$emit("getData");

                _this6.$message({
                  message: res.msg,
                  type: "success"
                });

                console.log(res);
                _context6.next = 21;
                break;

              case 18:
                _context6.prev = 18;
                _context6.t0 = _context6["catch"](8);
                console.log(_context6.t0);

              case 21:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, null, [[8, 18]]);
      }))();
    },
    close: function close() {
      this.value = "";
      this.desImgShow = true;
      this.isFirstImgShow = true;
      this.isfaceImgShow = true;
      this.$emit("setDialogVisible");
      this.$refs.faceImg.clearFiles();
      this.$refs.uploadFirst.clearFiles();
      this.$refs.uploadTwo.clearFiles();
    }
  },
  components: {}
});
// CONCATENATED MODULE: ./src/views/goodsManage/generalGoods/goods.vue?vue&type=script&lang=js&
 /* harmony default export */ var generalGoods_goodsvue_type_script_lang_js_ = (goodsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/views/goodsManage/generalGoods/goods.vue?vue&type=style&index=0&id=12335ba3&lang=scss&scoped=true&
var goodsvue_type_style_index_0_id_12335ba3_lang_scss_scoped_true_ = __webpack_require__("l5dJ");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("KHd+");

// CONCATENATED MODULE: ./src/views/goodsManage/generalGoods/goods.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  generalGoods_goodsvue_type_script_lang_js_,
  goodsvue_type_template_id_12335ba3_scoped_true_render,
  goodsvue_type_template_id_12335ba3_scoped_true_staticRenderFns,
  false,
  null,
  "12335ba3",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/goodsManage/generalGoods/goods.vue"
/* harmony default export */ var goods = (component.exports);
// EXTERNAL MODULE: ./src/components/details.vue + 4 modules
var details = __webpack_require__("JXHu");

// CONCATENATED MODULE: ./node_modules/happypack/loader.js?id=babel!./node_modules/vue-loader/lib??vue-loader-options!./src/views/goodsManage/generalGoods/first.vue?vue&type=script&lang=js&


//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var firstvue_type_script_lang_js_ = ({
  data: function data() {
    return {
      // 开始时间
      startTime: "",
      // 结束时间
      endTime: "",
      // 选中的商品状态
      options: [{
        value: "选项1",
        label: "黄金糕"
      }, {
        value: "选项2",
        label: "双皮奶"
      }, {
        value: "选项3",
        label: "蚵仔煎"
      }, {
        value: "选项4",
        label: "龙须面"
      }, {
        value: "选项5",
        label: "北京烤鸭"
      }],
      value: "",
      pickerOptions: {
        disabledDate: function disabledDate(time) {
          return time.getTime() > Date.now();
        }
      },
      dialogVisible: false,
      rowData: {},
      detailsVisible: false,
      scope: "scope",
      // 每页条目数
      limit: 11,
      // 获取哪一页数据
      pages: 1,
      // 批量数据操作的id
      selectedIds: [],
      tableData: [],
      goodsDetail: {}
    };
  },
  created: function created() {
    this.getGoods();
  },
  methods: {
    // 搜索
    serach: function serach() {
      console.log(111);
    },
    // 普通商品列表
    getGoods: function getGoods() {
      var _this = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee() {
        var res;
        return regenerator_default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.prev = 0;
                _context.next = 3;
                return _this.axios.get("/goods/list", {
                  params: {
                    limit: _this.limit,
                    pages: _this.pages,
                    // 普通商品
                    type: 2,
                    // 一审
                    audit: 0
                  }
                });

              case 3:
                res = _context.sent;
                _this.tableData = Object.assign(res.data, {
                  list: res.data.list.map(function (item) {
                    return Object.assign(item, {
                      status: item.audit === 1 ? true : false,
                      desStatus: item.audit === 0 ? "审核中" : " 通过 "
                    });
                  })
                });
                _context.next = 10;
                break;

              case 7:
                _context.prev = 7;
                _context.t0 = _context["catch"](0);
                console.log(_context.t0);

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[0, 7]]);
      }))();
    },
    // 批量操作
    handleSelect: function handleSelect(value) {
      this.selectedIds = value.map(function (item) {
        return item.id;
      });
    },
    // 批量审核

    /**
    *  @param status
    *  1 通过
    *  0 驳回
    *
    */
    pass: function pass(status) {
      var _this2 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee2() {
        return regenerator_default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!(_this2.selectedIds.length < 1)) {
                  _context2.next = 2;
                  break;
                }

                return _context2.abrupt("return");

              case 2:
                _context2.next = 4;
                return _this2.axios.post("/goods/examine", {
                  id: _this2.selectedIds,
                  // 1 通过 0 驳回
                  type: status
                });

              case 4:
                _this2.$refs.table.clearSelection();

                _this2.getGoods();

              case 6:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    // 修改
    modify: function modify(id) {
      var _this3 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee3() {
        var res;
        return regenerator_default.a.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.prev = 0;
                _context3.next = 3;
                return _this3.axios.get("/goods/details", {
                  params: {
                    id: id
                  }
                });

              case 3:
                res = _context3.sent;
                _this3.goodsDetail = res.data.list[0];
                _this3.dialogVisible = true;
                _context3.next = 11;
                break;

              case 8:
                _context3.prev = 8;
                _context3.t0 = _context3["catch"](0);
                console.log(_context3.t0);

              case 11:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, null, [[0, 8]]);
      }))();
    },
    // 预览
    rowSee: function rowSee(row) {
      this.detailsVisible = true;
      this.rowData = JSON.parse(JSON.stringify(row));

      for (var i = 0; i < this.rowData.first_img.length; i++) {
        var url = this.rowData.first_img[i],
            filename = url,
            index = filename.lastIndexOf("."),
            suffix = filename.substr(index + 1).toLowerCase(),
            suffixVal = 0;

        if (suffix === "mp4" || suffix === "flv" || suffix === "avi" || suffix === "rm" || suffix === "rmvb") {
          suffixVal = 1;
        }

        this.rowData.first_img[i] = {
          url: url,
          suffixVal: suffixVal
        };
      }
    },
    // 通过 驳回
    change: function change(item) {
      var _this4 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee4() {
        return regenerator_default.a.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.prev = 0;
                _context4.next = 3;
                return _this4.axios.post("/goods/examine", {
                  id: [item.id],
                  //  audit 1 为商品审核通过 0 为驳回
                  type: item.audit === 0 ? 1 : 0
                });

              case 3:
                _this4.getGoods();

                _context4.next = 9;
                break;

              case 6:
                _context4.prev = 6;
                _context4.t0 = _context4["catch"](0);
                console.log(_context4.t0);

              case 9:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, null, [[0, 6]]);
      }))();
    },
    // 预览
    preview: function preview(id) {
      var _this5 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee5() {
        var res;
        return regenerator_default.a.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.prev = 0;
                _context5.next = 3;
                return _this5.axios.get("/goods/details", {
                  params: {
                    id: id
                  }
                });

              case 3:
                res = _context5.sent;
                _this5.goodsDetail = res.data.list[0];
                console.log(_this5.goodsDetail);
                _this5.previewStatus = true;
                _context5.next = 12;
                break;

              case 9:
                _context5.prev = 9;
                _context5.t0 = _context5["catch"](0);
                console.log(_context5.t0);

              case 12:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, null, [[0, 9]]);
      }))();
    },
    // 上一页
    prev: function prev() {
      this.pages--;
      this.getGoods();
    },
    // 翻页
    changePage: function changePage(page) {
      this.pages = page;
      this.getGoods();
    },
    // 下一页
    next: function next() {
      this.pages++;
      this.getGoods();
    },
    setDialogVisible: function setDialogVisible() {
      this.dialogVisible = false;
    }
  },
  components: {
    Goods: goods,
    Detail: details["a" /* default */]
  }
});
// CONCATENATED MODULE: ./src/views/goodsManage/generalGoods/first.vue?vue&type=script&lang=js&
 /* harmony default export */ var generalGoods_firstvue_type_script_lang_js_ = (firstvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/views/goodsManage/generalGoods/first.vue?vue&type=style&index=0&id=71fd4c06&lang=scss&scoped=true&
var firstvue_type_style_index_0_id_71fd4c06_lang_scss_scoped_true_ = __webpack_require__("6NZq");

// CONCATENATED MODULE: ./src/views/goodsManage/generalGoods/first.vue






/* normalize component */

var first_component = Object(componentNormalizer["a" /* default */])(
  generalGoods_firstvue_type_script_lang_js_,
  firstvue_type_template_id_71fd4c06_scoped_true_render,
  firstvue_type_template_id_71fd4c06_scoped_true_staticRenderFns,
  false,
  null,
  "71fd4c06",
  null
  
)

/* hot reload */
if (false) { var first_api; }
first_component.options.__file = "src/views/goodsManage/generalGoods/first.vue"
/* harmony default export */ var first = (first_component.exports);
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./src/views/goodsManage/generalGoods/second.vue?vue&type=template&id=3ea386f7&scoped=true&
var secondvue_type_template_id_3ea386f7_scoped_true_render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "qucklyGoods" },
    [
      _c("Goods", {
        attrs: {
          "goods-detail": _vm.goodsDetail,
          "dialog-visible": _vm.dialogVisible
        },
        on: { getData: _vm.getGoods, setDialogVisible: _vm.setDialogVisible }
      }),
      _vm._v(" "),
      _c("Detail", {
        attrs: {
          "details-visible": _vm.detailsVisible,
          "row-data": _vm.rowData
        },
        on: {
          "update:detailsVisible": function($event) {
            _vm.detailsVisible = $event
          },
          "update:details-visible": function($event) {
            _vm.detailsVisible = $event
          }
        }
      }),
      _vm._v(" "),
      _c("header", { staticClass: "header" }, [
        _c(
          "div",
          { staticClass: "search-container" },
          [
            _c("el-date-picker", {
              attrs: {
                type: "date",
                placeholder: "开始时间",
                "picker-options": _vm.pickerOptions
              },
              model: {
                value: _vm.startTime,
                callback: function($$v) {
                  _vm.startTime = $$v
                },
                expression: "startTime"
              }
            }),
            _vm._v(" "),
            _c("el-date-picker", {
              attrs: {
                type: "date",
                placeholder: "结束时间",
                "picker-options": _vm.pickerOptions
              },
              model: {
                value: _vm.endTime,
                callback: function($$v) {
                  _vm.endTime = $$v
                },
                expression: "endTime"
              }
            }),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "bus_name" },
              [_c("el-input", { attrs: { placeholder: "请输入商家名称" } })],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "shop_name" },
              [_c("el-input", { attrs: { placeholder: "请输入商品名称" } })],
              1
            ),
            _vm._v(" "),
            _c(
              "el-select",
              {
                staticStyle: { width: "120px" },
                attrs: { placeholder: "商品状态", clearable: "" },
                model: {
                  value: _vm.value,
                  callback: function($$v) {
                    _vm.value = $$v
                  },
                  expression: "value"
                }
              },
              _vm._l(_vm.options, function(item) {
                return _c("el-option", {
                  key: item.value,
                  attrs: { label: item.label, value: item.value }
                })
              }),
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "search-btn", on: { click: _vm.serach } },
              [_vm._v("\n        确定\n      ")]
            )
          ],
          1
        ),
        _vm._v(" "),
        _c("section", { staticClass: "throughContainer" }, [
          _c(
            "div",
            {
              staticClass: "through",
              on: {
                click: function($event) {
                  return _vm.pass(1)
                }
              }
            },
            [_vm._v("\n        批量上架\n      ")]
          ),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "through",
              on: {
                click: function($event) {
                  return _vm.pass(0)
                }
              }
            },
            [_vm._v("\n        批量下架\n      ")]
          )
        ])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "table" },
        [
          _c(
            "el-table",
            {
              ref: "table",
              staticStyle: {},
              attrs: {
                data: _vm.tableData.list,
                border: "",
                "header-cell-style": { "text-align": "center", color: "black" },
                "cell-style": { "text-align": "center", padding: "5px 0" }
              },
              on: { "selection-change": _vm.handleSelect }
            },
            [
              _c("el-table-column", {
                attrs: { type: "selection", width: "60px" }
              }),
              _vm._v(" "),
              _c("el-table-column", { attrs: { prop: "id", label: "序号" } }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: {
                  prop: "goods_name",
                  label: "商品名称",
                  "show-overflow-tooltip": true
                }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "封面" },
                scopedSlots: _vm._u([
                  {
                    key: "default",
                    fn: function(scope) {
                      return [
                        _c("img", {
                          staticStyle: { width: "40px", height: "40px" },
                          attrs: { src: scope.row.cover_img }
                        })
                      ]
                    }
                  }
                ])
              }),
              _vm._v(" "),
              _c("el-table-column", { attrs: { prop: "sort", label: "排序" } }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "库存", prop: "inventory" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "支付类型", prop: "pay_type" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "原价", prop: "original_price" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "市场价", prop: "market_price" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "积分价格", prop: "is_integral" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "优惠券价格", prop: "coupons_price" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: { label: "状态", prop: "desStatus" }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: {
                  prop: "created_at",
                  label: "创建时间",
                  "show-overflow-tooltip": true
                }
              }),
              _vm._v(" "),
              _c("el-table-column", {
                attrs: {
                  prop: "updated_at",
                  label: "更新时间",
                  "show-overflow-tooltip": true
                }
              }),
              _vm._v(" "),
              _c(
                "el-table-column",
                {
                  attrs: { width: "300px" },
                  scopedSlots: _vm._u([
                    {
                      key: "default",
                      fn: function(scope) {
                        return [
                          _c(
                            "el-button",
                            {
                              attrs: { size: "mini" },
                              on: {
                                click: function($event) {
                                  return _vm.modify(scope.row.id)
                                }
                              }
                            },
                            [_vm._v("\n            修改\n          ")]
                          ),
                          _vm._v(" "),
                          _c(
                            "el-button",
                            {
                              attrs: { type: "primary", size: "mini" },
                              on: {
                                click: function($event) {
                                  return _vm.rowSee(scope.row)
                                }
                              }
                            },
                            [_vm._v("\n            预览\n          ")]
                          ),
                          _vm._v(" "),
                          _c("el-switch", {
                            staticStyle: { "margin-left": "30px" },
                            attrs: {
                              "active-text": "上架",
                              "inactive-text": "下架"
                            },
                            on: {
                              change: function($event) {
                                return _vm.change(scope.row)
                              }
                            },
                            model: {
                              value: scope.row.status,
                              callback: function($$v) {
                                _vm.$set(scope.row, "status", $$v)
                              },
                              expression: "scope.row.status"
                            }
                          })
                        ]
                      }
                    }
                  ])
                },
                [
                  _c(
                    "template",
                    { attrs: { "slot-scope": _vm.scope }, slot: "header" },
                    [_vm._v("\n          操作\n        ")]
                  )
                ],
                2
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "pagination" },
        [
          _c("el-pagination", {
            attrs: {
              layout: "prev,pager,next",
              background: "",
              "page-size": _vm.limit,
              total: _vm.tableData.total
            },
            on: {
              "current-change": _vm.changePage,
              "prev-click": _vm.prev,
              "next-click": _vm.next
            }
          })
        ],
        1
      )
    ],
    1
  )
}
var secondvue_type_template_id_3ea386f7_scoped_true_staticRenderFns = []
secondvue_type_template_id_3ea386f7_scoped_true_render._withStripped = true


// CONCATENATED MODULE: ./src/views/goodsManage/generalGoods/second.vue?vue&type=template&id=3ea386f7&scoped=true&

// CONCATENATED MODULE: ./node_modules/happypack/loader.js?id=babel!./node_modules/vue-loader/lib??vue-loader-options!./src/views/goodsManage/generalGoods/second.vue?vue&type=script&lang=js&


//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var secondvue_type_script_lang_js_ = ({
  data: function data() {
    return {
      // 开始时间
      startTime: "",
      // 结束时间
      endTime: "",
      // 选中的商品状态
      options: [{
        value: "选项1",
        label: "黄金糕"
      }, {
        value: "选项2",
        label: "双皮奶"
      }, {
        value: "选项3",
        label: "蚵仔煎"
      }, {
        value: "选项4",
        label: "龙须面"
      }, {
        value: "选项5",
        label: "北京烤鸭"
      }],
      value: "",
      pickerOptions: {
        disabledDate: function disabledDate(time) {
          return time.getTime() > Date.now();
        }
      },
      dialogVisible: false,
      rowData: {},
      detailsVisible: false,
      scope: "scope",
      // 每页条目数
      limit: 11,
      // 获取哪一页数据
      pages: 1,
      // 批量数据操作的id
      selectedIds: [],
      tableData: [],
      goodsDetail: {}
    };
  },
  created: function created() {
    this.getGoods();
  },
  methods: {
    // 搜索
    serach: function serach() {
      console.log(111);
    },
    // 普通商品列表
    getGoods: function getGoods() {
      var _this = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee() {
        var res;
        return regenerator_default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.prev = 0;
                _context.next = 3;
                return _this.axios.get("/goods/list", {
                  params: {
                    limit: _this.limit,
                    pages: _this.pages,
                    // 普通商品
                    type: 2,
                    // 二审
                    audit: 1
                  }
                });

              case 3:
                res = _context.sent;
                _this.tableData = Object.assign(res.data, {
                  list: res.data.list.map(function (item) {
                    return Object.assign(item, {
                      status: item.is_ground === 1 ? true : false,
                      desStatus: item.is_ground === 0 ? "下架" : "上架 "
                    });
                  })
                });
                _context.next = 10;
                break;

              case 7:
                _context.prev = 7;
                _context.t0 = _context["catch"](0);
                console.log(_context.t0);

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[0, 7]]);
      }))();
    },
    // 预览
    rowSee: function rowSee(row) {
      this.detailsVisible = true;
      this.rowData = JSON.parse(JSON.stringify(row));

      for (var i = 0; i < this.rowData.first_img.length; i++) {
        var url = this.rowData.first_img[i],
            filename = url,
            index = filename.lastIndexOf("."),
            suffix = filename.substr(index + 1).toLowerCase(),
            suffixVal = 0;

        if (suffix === "mp4" || suffix === "flv" || suffix === "avi" || suffix === "rm" || suffix === "rmvb") {
          suffixVal = 1;
        }

        this.rowData.first_img[i] = {
          url: url,
          suffixVal: suffixVal
        };
      }
    },
    // 批量操作
    handleSelect: function handleSelect(value) {
      this.selectedIds = value.map(function (item) {
        return item.id;
      });
    },
    // 批量审核

    /**
    *  @param status
    *  1 通过
    *  0 驳回
    *
    */
    pass: function pass(status) {
      var _this2 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee2() {
        return regenerator_default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!(_this2.selectedIds.length < 1)) {
                  _context2.next = 2;
                  break;
                }

                return _context2.abrupt("return");

              case 2:
                _context2.next = 4;
                return _this2.axios.post("/goods/shelves", {
                  id: _this2.selectedIds,
                  // 1 通过 0 驳回
                  type: status
                });

              case 4:
                _this2.$refs.table.clearSelection();

                _this2.getGoods();

              case 6:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    // 修改
    modify: function modify(id) {
      var _this3 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee3() {
        var res;
        return regenerator_default.a.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.prev = 0;
                _context3.next = 3;
                return _this3.axios.get("/goods/details", {
                  params: {
                    id: id
                  }
                });

              case 3:
                res = _context3.sent;
                _this3.goodsDetail = res.data.list[0];
                _this3.dialogVisible = true;
                _context3.next = 11;
                break;

              case 8:
                _context3.prev = 8;
                _context3.t0 = _context3["catch"](0);
                console.log(_context3.t0);

              case 11:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, null, [[0, 8]]);
      }))();
    },
    // 上架 下架
    change: function change(item) {
      var _this4 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee4() {
        return regenerator_default.a.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.prev = 0;
                _context4.next = 3;
                return _this4.axios.post("/goods/shelves", {
                  id: [item.id],
                  // is_ground  1 为上架 0 为下架
                  type: item.is_ground === 1 ? 0 : 1
                });

              case 3:
                _this4.getGoods();

                _context4.next = 9;
                break;

              case 6:
                _context4.prev = 6;
                _context4.t0 = _context4["catch"](0);
                console.log(_context4.t0);

              case 9:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, null, [[0, 6]]);
      }))();
    },
    // 上一页
    prev: function prev() {
      this.pages--;
      this.getGoods();
    },
    // 翻页
    changePage: function changePage(page) {
      this.pages = page;
      this.getGoods();
    },
    // 下一页
    next: function next() {
      this.pages++;
      this.getGoods();
    },
    setDialogVisible: function setDialogVisible() {
      this.dialogVisible = false;
    }
  },
  components: {
    Goods: goods,
    Detail: details["a" /* default */]
  }
});
// CONCATENATED MODULE: ./src/views/goodsManage/generalGoods/second.vue?vue&type=script&lang=js&
 /* harmony default export */ var generalGoods_secondvue_type_script_lang_js_ = (secondvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/views/goodsManage/generalGoods/second.vue?vue&type=style&index=0&id=3ea386f7&lang=scss&scoped=true&
var secondvue_type_style_index_0_id_3ea386f7_lang_scss_scoped_true_ = __webpack_require__("89QR");

// CONCATENATED MODULE: ./src/views/goodsManage/generalGoods/second.vue






/* normalize component */

var second_component = Object(componentNormalizer["a" /* default */])(
  generalGoods_secondvue_type_script_lang_js_,
  secondvue_type_template_id_3ea386f7_scoped_true_render,
  secondvue_type_template_id_3ea386f7_scoped_true_staticRenderFns,
  false,
  null,
  "3ea386f7",
  null
  
)

/* hot reload */
if (false) { var second_api; }
second_component.options.__file = "src/views/goodsManage/generalGoods/second.vue"
/* harmony default export */ var second = (second_component.exports);
// CONCATENATED MODULE: ./node_modules/happypack/loader.js?id=babel!./node_modules/vue-loader/lib??vue-loader-options!./src/views/goodsManage/generalGoods/generalGoods.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var generalGoodsvue_type_script_lang_js_ = ({
  data: function data() {
    return {
      goodsType: [{
        title: "一审",
        path: "First"
      }, {
        title: "二审",
        path: "Second"
      }],
      currentComponent: "First"
    };
  },
  components: {
    Second: second,
    First: first
  }
});
// CONCATENATED MODULE: ./src/views/goodsManage/generalGoods/generalGoods.vue?vue&type=script&lang=js&
 /* harmony default export */ var generalGoods_generalGoodsvue_type_script_lang_js_ = (generalGoodsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/views/goodsManage/generalGoods/generalGoods.vue?vue&type=style&index=0&id=7a35d891&lang=scss&scoped=true&
var generalGoodsvue_type_style_index_0_id_7a35d891_lang_scss_scoped_true_ = __webpack_require__("c8BC");

// CONCATENATED MODULE: ./src/views/goodsManage/generalGoods/generalGoods.vue






/* normalize component */

var generalGoods_component = Object(componentNormalizer["a" /* default */])(
  generalGoods_generalGoodsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "7a35d891",
  null
  
)

/* hot reload */
if (false) { var generalGoods_api; }
generalGoods_component.options.__file = "src/views/goodsManage/generalGoods/generalGoods.vue"
/* harmony default export */ var generalGoods = __webpack_exports__["default"] = (generalGoods_component.exports);

/***/ }),

/***/ "gfTd":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("66x0");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("SZ7m").default
var update = add("633faa2c", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "hboG":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("8Y6c");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("SZ7m").default
var update = add("83c6b08c", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "l5dJ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_goods_vue_vue_type_style_index_0_id_12335ba3_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hboG");
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_goods_vue_vue_type_style_index_0_id_12335ba3_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_goods_vue_vue_type_style_index_0_id_12335ba3_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_4_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_goods_vue_vue_type_style_index_0_id_12335ba3_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "s/Li":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("6WKZ");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("SZ7m").default
var update = add("e93ead08", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "tRuQ":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("0tDW");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("SZ7m").default
var update = add("7ed07b9d", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ })

}]);