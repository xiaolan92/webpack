(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[18],{

/***/ "xUzO":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./src/views/orderManage/orderManage.vue?vue&type=template&id=7bf2f826&scoped=true&
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [_c("router-view")], 1)
}
var staticRenderFns = []
render._withStripped = true


// CONCATENATED MODULE: ./src/views/orderManage/orderManage.vue?vue&type=template&id=7bf2f826&scoped=true&

// CONCATENATED MODULE: ./node_modules/happypack/loader.js?id=babel!./node_modules/vue-loader/lib??vue-loader-options!./src/views/orderManage/orderManage.vue?vue&type=script&lang=js&
//
//
//
//
//
//
/* harmony default export */ var orderManagevue_type_script_lang_js_ = ({
  data: function data() {
    return {};
  },
  components: {}
});
// CONCATENATED MODULE: ./src/views/orderManage/orderManage.vue?vue&type=script&lang=js&
 /* harmony default export */ var orderManage_orderManagevue_type_script_lang_js_ = (orderManagevue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("KHd+");

// CONCATENATED MODULE: ./src/views/orderManage/orderManage.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  orderManage_orderManagevue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "7bf2f826",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/orderManage/orderManage.vue"
/* harmony default export */ var orderManage = __webpack_exports__["default"] = (component.exports);

/***/ })

}]);