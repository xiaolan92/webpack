(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[20],{

/***/ "p8Ru":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./src/views/qucklyQueen/qucklyQueenList.vue?vue&type=template&id=6327a6a7&scoped=true&
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [_vm._v("\n  抢单队列管理\n")])
}
var staticRenderFns = []
render._withStripped = true


// CONCATENATED MODULE: ./src/views/qucklyQueen/qucklyQueenList.vue?vue&type=template&id=6327a6a7&scoped=true&

// CONCATENATED MODULE: ./node_modules/happypack/loader.js?id=babel!./node_modules/vue-loader/lib??vue-loader-options!./src/views/qucklyQueen/qucklyQueenList.vue?vue&type=script&lang=js&
//
//
//
//
//
//
/* harmony default export */ var qucklyQueenListvue_type_script_lang_js_ = ({
  data: function data() {
    return {};
  },
  components: {}
});
// CONCATENATED MODULE: ./src/views/qucklyQueen/qucklyQueenList.vue?vue&type=script&lang=js&
 /* harmony default export */ var qucklyQueen_qucklyQueenListvue_type_script_lang_js_ = (qucklyQueenListvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("KHd+");

// CONCATENATED MODULE: ./src/views/qucklyQueen/qucklyQueenList.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  qucklyQueen_qucklyQueenListvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "6327a6a7",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/qucklyQueen/qucklyQueenList.vue"
/* harmony default export */ var qucklyQueenList = __webpack_exports__["default"] = (component.exports);

/***/ })

}]);