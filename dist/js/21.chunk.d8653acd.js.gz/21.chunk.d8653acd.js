(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[21],{

/***/ "PU8r":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnGoodsManager/returnGoodsList.vue?vue&type=template&id=7ff71616&scoped=true&
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [_vm._v("\n  退货列表\n")])
}
var staticRenderFns = []
render._withStripped = true


// CONCATENATED MODULE: ./src/views/returnGoodsManager/returnGoodsList.vue?vue&type=template&id=7ff71616&scoped=true&

// CONCATENATED MODULE: ./node_modules/happypack/loader.js?id=babel!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnGoodsManager/returnGoodsList.vue?vue&type=script&lang=js&
//
//
//
//
//
//
/* harmony default export */ var returnGoodsListvue_type_script_lang_js_ = ({
  data: function data() {
    return {};
  },
  components: {}
});
// CONCATENATED MODULE: ./src/views/returnGoodsManager/returnGoodsList.vue?vue&type=script&lang=js&
 /* harmony default export */ var returnGoodsManager_returnGoodsListvue_type_script_lang_js_ = (returnGoodsListvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("KHd+");

// CONCATENATED MODULE: ./src/views/returnGoodsManager/returnGoodsList.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  returnGoodsManager_returnGoodsListvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "7ff71616",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/returnGoodsManager/returnGoodsList.vue"
/* harmony default export */ var returnGoodsList = __webpack_exports__["default"] = (component.exports);

/***/ })

}]);